Technical report template
-------------------------

Clone, write, make.

